# GL Cloud Documentation

Welcome to the glcloud.app  Documentation! This documentation provides detailed information on how to interact with the glcloud.app to manage and deploy your applications on the GL Cloud platform.

Using the Mintlify documentation framework, we have created a simple and easy to use documentation site. The documentation site is available at [https://docs.glcloud.app](https://docs.glcloud.app).